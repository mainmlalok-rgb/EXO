import makeWASocket, {
  useMultiFileAuthState,
  DisconnectReason,
  fetchLatestBaileysVersion,
} from '@whiskeysockets/baileys'
import pino from 'pino'
import qrcode from 'qrcode-terminal'

const PREFIX = '!'
const logger = pino({ level: 'silent' })

// Ambil teks dari berbagai tipe pesan
function getText(msg) {
  const m = msg.message
  if (!m) return ''
  return (
    m.conversation ||
    m.extendedTextMessage?.text ||
    m.imageMessage?.caption ||
    m.videoMessage?.caption ||
    ''
  )
}

// Balasan bot: ubah/tambah sesuka Anda
function buatBalasan(teks) {
  const t = teks.trim().toLowerCase()

  if (['hai', 'halo', 'hi', 'hello', 'p'].includes(t)) {
    return 'Halo! 👋 Saya bot WhatsApp sederhana. Ketik *!menu* untuk melihat perintah.'
  }
  if (t === PREFIX + 'menu') {
    return [
      '*📋 MENU BOT*',
      '',
      '!menu  - tampilkan menu',
      '!ping  - cek bot aktif',
      '!waktu - tanggal & jam sekarang',
      '!halo  - sapaan',
    ].join('\n')
  }
  if (t === PREFIX + 'ping') return 'Pong! 🏓 Bot aktif.'
  if (t === PREFIX + 'halo') return 'Halo juga! 😊'
  if (t === PREFIX + 'waktu') {
    return new Date().toLocaleString('id-ID', {
      dateStyle: 'full',
      timeStyle: 'medium',
      timeZone: 'Asia/Jakarta',
    }) + ' WIB'
  }
  if (t.startsWith(PREFIX)) {
    return 'Perintah tidak dikenal. Ketik *!menu* untuk daftar perintah.'
  }
  return null // pesan biasa: tidak dibalas
}

async function mulaiBot() {
  const { state, saveCreds } = await useMultiFileAuthState('sesi')
  const { version } = await fetchLatestBaileysVersion()

  const sock = makeWASocket({
    version,
    auth: state,
    logger,
    browser: ['Bot WA Sederhana', 'Chrome', '1.0.0'],
  })

  sock.ev.on('creds.update', saveCreds)

  sock.ev.on('connection.update', ({ connection, lastDisconnect, qr }) => {
    if (qr) {
      console.log('\nScan QR berikut: WhatsApp > Perangkat Tertaut > Tautkan Perangkat\n')
      qrcode.generate(qr, { small: true })
    }

    if (connection === 'open') {
      console.log('✅ Bot terhubung ke WhatsApp!')
    }

    if (connection === 'close') {
      const kode = lastDisconnect?.error?.output?.statusCode
      if (kode === DisconnectReason.loggedOut) {
        console.log('❌ Sesi logout. Hapus folder "sesi" lalu jalankan ulang untuk scan QR baru.')
      } else {
        console.log('⚠️ Koneksi terputus, mencoba menyambung ulang...')
        mulaiBot()
      }
    }
  })

  sock.ev.on('messages.upsert', async ({ messages, type }) => {
    if (type !== 'notify') return

    for (const msg of messages) {
      if (!msg.message || msg.key.fromMe) continue
      if (msg.key.remoteJid === 'status@broadcast') continue

      const teks = getText(msg)
      if (!teks) continue

      const balasan = buatBalasan(teks)
      if (!balasan) continue

      try {
        await sock.sendMessage(msg.key.remoteJid, { text: balasan }, { quoted: msg })
      } catch (err) {
        console.error('Gagal mengirim balasan:', err.message)
      }
    }
  })
}

mulaiBot().catch((err) => {
  console.error('Bot gagal dijalankan:', err)
  process.exit(1)
})
